# Sistema de Matrícula — Escola de Artes

Aplicação React + Vite para cadastro de alunos, matrículas, consulta, edição, geração de PDF e administração de usuários. Os dados oficiais ficam no Google Sheets; as fotos ficam no Google Drive e a planilha armazena apenas a URL da imagem.

## Onde cada dado fica

| Dado | Armazenamento oficial |
|---|---|
| Alunos | Aba `ALUNOS` da planilha |
| Matrículas | Aba `MATRICULAS` |
| Usuários comuns | Aba `LOGINS` |
| Registros excluídos | Aba `EXCLUIDOS` |
| Fotos | Pasta `Fotos_Alunos_EscolaDeArtes` no Drive do proprietário do Apps Script |
| URL do Apps Script | `src/config.ts` |
| Layout padrão do PDF | `src/services/pdfLayout.saved.ts` |
| Ajustes locais do layout | navegador, somente para o administrador que estiver ajustando |
| Fundos do PDF | `public/pdf/` |

Alunos, matrículas, fotos, usuários e URL de conexão não são persistidos no navegador. Enquanto a página está aberta, alunos e matrículas ficam apenas em memória para exibição.

## Requisitos

- Node.js 20 ou superior
- npm
- Uma planilha Google
- Um projeto Google Apps Script vinculado à planilha

## Instalação local

```bash
npm install
npm run dev
```

Validação e produção:

```bash
npm run lint
npm run build
npm run preview
```

## Configurar o Google Apps Script

1. Abra a planilha.
2. Acesse **Extensões → Apps Script**.
3. Substitua o conteúdo pelo arquivo `Code.gs` deste repositório.
4. Salve.
5. Acesse **Implantar → Nova implantação** ou edite a implantação existente.
6. Escolha **Aplicativo da Web**.
7. Execute como sua conta e permita acesso para qualquer pessoa que usará o sistema.
8. Copie a URL terminada em `/exec`.
9. Cole essa URL em `DEFAULT_APPS_SCRIPT_URL`, no arquivo `src/config.ts`.

A versão esperada pelo frontend é `EA_APP_2026_07_29_01`. Gravações e exclusões são bloqueadas quando o Apps Script está em outra versão.

## Como as fotos são salvas no Drive

A webcam gera uma imagem temporária em Base64 apenas durante o cadastro. Ao confirmar:

1. O frontend envia a imagem ao Apps Script.
2. O Apps Script decodifica o Base64.
3. Cria ou reutiliza a pasta `Fotos_Alunos_EscolaDeArtes`.
4. Salva o arquivo de imagem no Drive.
5. Grava somente a URL da foto na coluna `Foto do aluno` da aba `ALUNOS`.
6. Ao trocar a foto, a antiga é enviada para a lixeira.
7. Ao excluir o aluno, a foto vinculada também é enviada para a lixeira.

Na primeira gravação, o Google poderá solicitar autorização para o Apps Script acessar o Drive.

## Estrutura das abas

O Apps Script cria as abas e adiciona colunas ausentes automaticamente. Não renomeie:

- `ALUNOS`
- `MATRICULAS`
- `EXCLUIDOS`
- `LOGINS`

A aba `LOGINS` usa:

```text
NOME | LOGIN | SENHA
```

O administrador permanece definido no frontend em `src/config.ts`, conforme a decisão do projeto. Usuários comuns são autenticados pela aba `LOGINS`.

## Layout do PDF

O layout compartilhado está em:

```text
src/services/pdfLayout.saved.ts
```

Os fundos estão em:

```text
public/pdf/fundo-pagina-1.jpg
public/pdf/fundo-pagina-2.jpg
```

O painel administrativo pode manter ajustes temporários no navegador. Para publicar um novo padrão para todos, use a opção de salvar no código, substitua `pdfLayout.saved.ts`, faça commit e publique uma nova versão.

## Publicar no GitHub

```bash
git init
git add .
git commit -m "Publicação inicial"
git branch -M main
git remote add origin URL_DO_REPOSITORIO
git push -u origin main
```

O `.gitignore` impede o envio de `node_modules`, `dist`, arquivos de ambiente, logs e arquivos temporários.

### GitHub Pages

Quando o site for publicado em um repositório com caminho próprio, configure `base` em `vite.config.ts` com o nome do repositório, por exemplo:

```ts
export default defineConfig({
  base: '/sistema-matricula/',
  // restante da configuração
});
```

Para domínio próprio, Netlify, Vercel ou Cloudflare Pages, normalmente `base: '/'` é suficiente.

## Atualização segura

Sempre que `Code.gs` mudar:

1. Atualize `APP_VERSION` no Apps Script.
2. Atualize `APP_SCRIPT_VERSION` em `src/services/api.ts` com o mesmo valor.
3. Implante uma nova versão do Apps Script.
4. Teste a conexão no painel antes de cadastrar ou excluir dados.

## Observações

- A senha do administrador está no código público porque isso foi solicitado para uso interno. Qualquer pessoa com acesso ao repositório poderá vê-la.
- As senhas dos usuários comuns permanecem visíveis para quem tem acesso de edição à planilha.
- O Google Sheets e o Drive são as fontes oficiais. Limpar os dados do navegador não remove cadastros.
